**Introduction**

This folder consists of the terraform code for the base repo, storage account and container that will hold the remote terraform state files.

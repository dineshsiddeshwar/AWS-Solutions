# **Secure_Baseline_Coding**

The Secure Baseline Coding repo, coantains terraform modules for the below listed Azure services, and follows security best parctices in implementing the resources.

1. Azure Key Vault
2. Azure SQL
3. Private Endpoint and Link Services
4. Application GateWay
5. Application Insights
6. Azure Databricks
7. Azure Data Factory
8. Azure Synapse
9. Azure Traffic Manager
10. Networks
11. Diagnostic Settings


# pkr-docops

## Requirements

No requirements.

## Providers

No providers.

## Modules

No modules.

## Resources

No resources.

## Inputs

| Name | Description | Type | Default | Required |
|------|-------------|------|---------|:--------:|
| bypassProxy | Comma separated list of strings that by-pass the configured proxy | `string` | n/a | yes |
| docops\_bucket\_name | Target bucket name that GCS Fuse will mount. | `string` | n/a | yes |
| environment | Associated Software Development Lifecycle Environment | `string` | n/a | yes |
| project\_id | The project ID that will be used to launch instances and store images. | `string` | n/a | yes |
| proxy\_server | Proxy IP address to use for internet access. | `string` | n/a | yes |
| service\_account\_email | The service account to be used for launched instance. | `string` | n/a | yes |
| vm\_subnet | Subnet for which to launch Compute Instances for Packer building | `string` | n/a | yes |
| zone | The zone in which to launch the instance used to create the image. | `string` | n/a | yes |
| gcsfuse\_version | Version of GCS Fuse to install. | `string` | `""` | no |
| iap\_tunnel\_launch\_wait | How long to wait, in seconds, before assuming a tunnel launch was successful. Defaults to 30 seconds for SSH or 40 seconds for WinRM. | `number` | `null` | no |
| remote\_folder | Remote folder/directory to be used for script execution.  (/tmp prevents script execution) | `string` | `"/opt/packer_build"` | no |
| skip\_create\_image | Skip creating the image. Useful for setting to true during a build test stage. | `bool` | `false` | no |
| source\_image\_project\_id | A list of project IDs to search for the source image. Packer will search the first project ID in the list first, and fall back to the next in the list, until it finds the source image. | `list(string)` | <pre>[<br>  "pid-gousgggp-ssvc-os-images"<br>]</pre> | no |
| ssh\_timeout | (duration string \| ex: '1h5m2s') - The time to wait for SSH to become available. Packer uses this to determine when the machine has booted so this is usually quite long. Example value: 10m. | `string` | `null` | no |
| ssh\_username | Username to be used by packer. Defaults to `packer` | `string` | `"packer"` | no |
| state\_timeout | The time to wait for instance state changes. | `string` | `"5m"` | no |

## Outputs

No outputs.

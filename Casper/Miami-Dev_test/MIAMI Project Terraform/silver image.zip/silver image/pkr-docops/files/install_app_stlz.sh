#!/usr/bin/env bash
# Disable DNF Automatic Updates
# Causing terrible delays in machine startup. 15+ mimutes at times.
systemctl stop dnf-automatic.timer
systemctl stop dnf-automatic

############################
# Install Open-JDK
############################
echo "--------- yum install  ---JDK------"
#dnf clean all
#dnf update
#dnf install java-17-openjdk.x86_64 -y

curl -H "X-JFrog-Art-Api:AKCp8oh9hH8UDc3LsUdr1q9LHhqEaigxn7qQUVEwihuFmxSd8bRfuWV36cDjcZCLiRrGUsGny" -X GET "https://artifactory.globalpay.com/artifactory/maven-release-local-miami/softwares/openjdk-17.0.2_linux-x64_bin.tar.gz" --output openjdk-17.0.2_linux-x64_bin.tar.gz
tar -xvzf openjdk-17.0.2_linux-x64_bin.tar.gz

############################
# Install Open-JDK
############################
echo "--------- yum install  ---Tomcat------"

curl -H "X-JFrog-Art-Api:AKCp8oh9hH8UDc3LsUdr1q9LHhqEaigxn7qQUVEwihuFmxSd8bRfuWV36cDjcZCLiRrGUsGny" -X GET "https://artifactory.globalpay.com/artifactory/maven-release-local-miami/softwares/apache-tomcat-9.0.74.tar.gz" --output apache-tomcat-9.0.74.tar.gz
tar -xvzf apache-tomcat-9.0.74.tar.gz
bash apache-tomcat-9.0.74/bin/startup.sh









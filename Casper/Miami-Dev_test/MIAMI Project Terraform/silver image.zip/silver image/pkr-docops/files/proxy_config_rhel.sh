#!/bin/bash

############################
# Configure Proxy Settings
############################
if [[ $PROXY_IP =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  echo "--------- Configuring Proxy: $PROXY_IP ---------"
  # Configure bash, curl, wget, etc to use proxy
  touch /etc/profile.d/http_proxy.sh
  chmod 644 /etc/profile.d/http_proxy.sh
  chmod +x  /etc/profile.d/http_proxy.sh
  grep -qxF "proxy=http://$PROXY_IP:80" /etc/profile.d/http_proxy.sh || cat <<EOF > /etc/profile.d/http_proxy.sh
  export http_proxy="http://$PROXY_IP:80"
  export https_proxy="http://$PROXY_IP:80"
  export no_proxy="$NO_PROXY"
  export HTTP_PROXY="http://$PROXY_IP:80"
  export HTTPS_PROXY="http://$PROXY_IP:80"
  export NO_PROXY="$NO_PROXY"
EOF

  # Set Proxy Variables for this session
  export http_proxy="http://$PROXY_IP:80"
  export https_proxy="http://$PROXY_IP:80"
  export no_proxy="$NO_PROXY"
  export HTTP_PROXY="http://$PROXY_IP:80"
  export HTTPS_PROXY="http://$PROXY_IP:80"
  export NO_PROXY="$NO_PROXY"

  # Configure yum to use proxy
  grep -qxF "proxy=$PROXY_IP:80" /etc/yum.conf || echo proxy="http://$PROXY_IP:80" >> /etc/yum.conf
  grep -qxF "proxy=$PROXY_IP:80" /etc/dnf/dnf.conf || echo proxy="http://$PROXY_IP:80" >> /etc/dnf/dnf.conf
else
  echo "--------- Error invalid ProxyIP: $PROXY_IP ---------"
  exit 1
fi

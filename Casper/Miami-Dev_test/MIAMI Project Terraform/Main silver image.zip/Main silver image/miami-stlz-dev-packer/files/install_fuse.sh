#!/usr/bin/env bash
# Disable DNF Automatic Updates
# Causing terrible delays in machine startup. 15+ mimutes at times.
systemctl stop dnf-automatic.timer
systemctl stop dnf-automatic

############################
# Install Fuse
############################
echo "--------- yum install fuse ---------"
dnf clean all
sudo yum -y install fuse

############################
# Install GCSFuse
############################
echo "--------- Installing GCSFuse ---------"
if [ ! -f /etc/yum.repos.d/gcsfuse.repo ]; then
sudo tee /etc/yum.repos.d/gcsfuse.repo > /dev/null <<EOF
[gcsfuse]
name=gcsfuse (packages.cloud.google.com)
baseurl=https://packages.cloud.google.com/yum/repos/gcsfuse-el7-x86_64
enabled=1
gpgcheck=1
repo_gpgcheck=0
gpgkey=http://packages.cloud.google.com/yum/doc/yum-key.gpg
       http://packages.cloud.google.com/yum/doc/rpm-package-key.gpg
EOF
fi

sudo yum -y install gcsfuse-$GCSFUSE_VERSION

sudo mkdir /usr/share/nginx/$DOCOPS_BUCKET_NAME
chown nginx:nginx /usr/share/nginx/$DOCOPS_BUCKET_NAME

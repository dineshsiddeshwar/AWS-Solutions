#!/bin/bash -e

[ -e /etc/profile.d/http_proxy.sh ] && rm -f /etc/profile.d/http_proxy.sh || echo "/etc/profile.d/http_proxy.sh does not exist."
[ -e /etc/yum.conf ] && sed -i /proxy=/d /etc/yum.conf || echo "/etc/yum.conf does not exist."
[ -e /etc/dnf/dnf.conf ] && sed -i /proxy=/d /etc/dnf/dnf.conf || echo "/etc/dnf/dnf.conf does not exist."

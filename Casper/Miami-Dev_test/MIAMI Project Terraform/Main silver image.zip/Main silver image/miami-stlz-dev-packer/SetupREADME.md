# Steps Taken
Created two pipelines
- deploy tf-cpen-lz-images terraform job
- Custom image packer deployment job

Created and executed tf-cpen-lz-images
- created packer service account
- granted iap access
  - for support users
  - workload identity serviceAccountUser to packer SA

updates tf-cpen-svpc
- added cpen-lz-images as a service project

updated tf-cpen-svpc
- added packer service account as a target for IAP access

updated tf-cpen-svpc-firewall
- added access for packer to access squid servers

created/updated pkr-docops
- configured a manifest file to build images in the cpen-lz-images project.
- Variable Notes:
  - Set the subnet to the self-link of the SVPC subnet to be used.
    - could have added another variable/parameter to target network.
    - https://developer.hashicorp.com/packer/plugins/builders/googlecompute#network_project_id
  - Set Proxy server IP
    - This is the shared squid instance in the SVPC
  - Set project_id appropriately
  - Set service_account_email to the packer SA created in tf-cpen-lz-images

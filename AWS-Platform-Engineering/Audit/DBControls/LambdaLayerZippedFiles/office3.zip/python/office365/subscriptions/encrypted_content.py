from office365.runtime.client_value import ClientValue


class ChangeNotificationEncryptedContent(ClientValue):
    """Represents the encrypted data attached to a change notification."""

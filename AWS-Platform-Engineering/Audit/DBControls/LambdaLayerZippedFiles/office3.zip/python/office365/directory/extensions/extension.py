from office365.entity import Entity


class Extension(Entity):
    """An abstract type to support the OData v4 open type openTypeExtension."""
    pass

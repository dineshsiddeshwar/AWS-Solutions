from office365.entity import Entity


class Security(Entity):
    """The security resource is the entry point for the Security object model. It returns a singleton security resource.
     It doesn't contain any usable properties."""

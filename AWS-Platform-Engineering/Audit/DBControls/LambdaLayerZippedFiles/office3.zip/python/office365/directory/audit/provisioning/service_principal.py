from office365.directory.identities.identity import Identity


class ProvisioningServicePrincipal(Identity):
    """Represents the service principal used for provisioning."""

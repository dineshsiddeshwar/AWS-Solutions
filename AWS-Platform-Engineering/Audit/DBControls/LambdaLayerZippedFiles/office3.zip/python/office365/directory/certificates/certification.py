from office365.runtime.client_value import ClientValue


class Certification(ClientValue):
    """Represents the certification details of an application."""

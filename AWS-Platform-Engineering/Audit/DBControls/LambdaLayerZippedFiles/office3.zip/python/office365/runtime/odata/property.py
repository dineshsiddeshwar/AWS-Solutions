class ODataProperty(object):

    def __init__(self, name=None, read_only=None):
        self.name = name
        self.ReadOnly = read_only


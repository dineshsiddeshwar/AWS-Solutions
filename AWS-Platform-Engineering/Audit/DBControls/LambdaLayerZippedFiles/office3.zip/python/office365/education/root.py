from office365.entity import Entity


class EducationRoot(Entity):
    """The /education namespace exposes functionality that is specific to the education sector. """
    pass



class WellknownListName:
    pass

from office365.sharepoint.base_entity import BaseEntity


class TenantAppInstance(BaseEntity):
    """Represents an instance of a tenant-scoped app for a given host web."""



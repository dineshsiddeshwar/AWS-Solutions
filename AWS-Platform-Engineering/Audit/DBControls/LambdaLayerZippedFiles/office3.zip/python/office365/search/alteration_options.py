from office365.runtime.client_value import ClientValue


class AlterationOptions(ClientValue):
    """Provides the search alteration options for spelling correction."""

from office365.runtime.client_value import ClientValue


class SortProperty(ClientValue):
    """Indicates the order to sort search results."""

class ColumnTypes:

    text = "text"
    """Single line text."""

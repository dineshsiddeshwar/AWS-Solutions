from office365.entity import Entity


class WorkbookCommentReply(Entity):
    """Represents a reply to an Excel comment."""

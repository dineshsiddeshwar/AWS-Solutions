from office365.runtime.client_value import ClientValue


class ItemActionStat(ClientValue):
    """The itemActionStat resource provides aggregate details about an action over a period of time."""

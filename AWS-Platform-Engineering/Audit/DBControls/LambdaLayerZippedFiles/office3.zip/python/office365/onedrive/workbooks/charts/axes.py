from office365.entity import Entity


class WorkbookChartAxes(Entity):
    """Represents the chart axes."""
    pass

from office365.entity import Entity


class WorkbookChartDataLabels(Entity):
    """Represents a collection of all the data labels on a chart point."""
    pass

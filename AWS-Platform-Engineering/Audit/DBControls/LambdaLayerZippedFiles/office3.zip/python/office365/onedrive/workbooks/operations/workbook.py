from office365.entity import Entity


class WorkbookOperation(Entity):
    """Represents the status of a long-running workbook operation"""

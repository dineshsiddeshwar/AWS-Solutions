from office365.entity import Entity


class WorkbookFilter(Entity):
    """Manages the filtering of a table's column."""
